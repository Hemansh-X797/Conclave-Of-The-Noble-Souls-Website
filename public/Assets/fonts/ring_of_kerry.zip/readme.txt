OTF and TTF: Ring of Kerry
Dennis Ludlow 2016 all rights reserved
by Sharkshock 
dennis@sharkshock.net

How's about yee my lads and lassies? The Ring of Kerry is sure to put a smile on your face and a song in your heart! This decorative display font should fill your needs for beautifuly crafted Irish style lettering. Medieval gaelic meets unical script in a fusion of mostly circle based characters
designed to repeat themselves and take up horizontal space. While it's majuscule in nature there are several "alternates" found in the lowercase letters to give a bit of variety. Basic latin, punctuation, European accents, kerning, and a few Celtic knots are available. These can be accessed by using 
your program's glyphs panel. If your program doesn't support OTF features try some of the trademark symbols such as � and �. Use it for greeting cards, posters, or a pub logo. 

This font like my others are free for personal use only as long as this readme file stays intact. For commercial use please contact me at dennis@sharkshock.net to discuss an end user license agreement. You can also visit www.sharkshock.net/license for more info. I also design custom fonts for
businesses, logos, and many other things. If you'd like to leave me a PayPal donation you can use my email address above. Your generosity will be most appreciated! 


visit www.sharkshock.net for more and take a bite out of BORING design!

tags: stylish, display, font, typeface, publishing, logo, title, book, cover, company, brand, branding, poster, beer, Eire, Ireland, Europe, medieval, lettering, unical, celtic, gaelic, st. patrick's day, Dublin, Cork, Kerry, Gallway, Limerick, Glendalough, pub, hall, Irish, stout, Guinness, Murphy's, green, luck